from django.http import HttpResponse

def home(response):
    return HttpResponse('Welcome to our first django app!')
